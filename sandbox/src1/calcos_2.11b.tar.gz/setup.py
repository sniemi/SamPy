from distutils.core import setup, Extension
from distutils import sysconfig
import sys, os.path
import numpy

pythoninc = sysconfig.get_python_inc()

numpyinc = numpy.get_include()

args = sys.argv[:]
for a in args:
    if a.startswith ('--local='):
        dir = os.path.abspath (a.split ("=")[1])
        sys.argv.extend ([
                "--install-lib="+dir,
                ])
        #remove --local from both sys.argv and args
        args.remove (a)
        sys.argv.remove (a)

def getExtensions_numpy (args):
    ext = [Extension ("ccos", ["ccos.c"],
           define_macros = [('NUMPY', '1')],
           include_dirs = [pythoninc, numpyinc])]
    return ext


def dosetup (ext):
    r = setup (name = "ccos",
               version = "1.0",
               description = "C extension module for calcos",
               author = "Phil Hodge",
               author_email = "help@stsci.edu",
               platforms = ["Linux", "Solaris", "Mac OS X", "Windows"],
               packages = [""],
               package_dir = {"":""},
               ext_modules = ext)
    return r


if __name__ == "__main__":
    ext = getExtensions_numpy (args)
    dosetup (ext)
